*PADS-LIBRARY-PART-TYPES-V9*

AS5047P-ATSM SOP65P640X120-14N I ANA 9 1 0 0 0
TIMESTAMP 2026.02.25.14.43.29
"Manufacturer_Name" ams OSRAM
"Manufacturer_Part_Number" AS5047P-ATSM
"Mouser Part Number" 985-AS5047P-ATSM
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ams-OSRAM/AS5047P-ATSM?qs=cGEy3R83DS8fzNOVLHtOgg%3D%3D
"Arrow Part Number" AS5047P-ATSM
"Arrow Price/Stock" https://www.arrow.com/en/products/as5047p-atsm/ams-osram?utm_currency=USD&region=nac
"Description" Board Mount Hall Effect / Magnetic Sensors 14 bit core res Up to 28krpm
"Datasheet Link" https://datasheet.datasheetarchive.com/originals/distributors/DKDS-7/120640.pdf
"Geometry.Height" 1.2mm
GATE 1 14 0
AS5047P-ATSM
1 0 U CSN
2 0 U CLK
3 0 U MISO
4 0 U MOSI
5 0 U TEST
6 0 U B
7 0 U A
14 0 U I/PWM
13 0 U GND
12 0 U VDD3V
11 0 U VDD
10 0 U U
9 0 U V
8 0 U W/PWM

*END*
*REMARK* SamacSys ECAD Model
368642/1906581/2.50/14/3/Integrated Circuit
