*PADS-LIBRARY-PART-TYPES-V9*

AT24C32D-SSHM-B SOIC127P600X175-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.02.25.14.31.57
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" AT24C32D-SSHM-B
"Mouser Part Number" 556-AT24C32D-SSHM-B
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/AT24C32D-SSHM-B?qs=ZZMt4ii29sN2mTRLl%2FnVJA%3D%3D
"Arrow Part Number" AT24C32D-SSHM-B
"Arrow Price/Stock" https://www.arrow.com/en/products/at24c32d-sshm-b/microchip-technology?utm_currency=USD&region=europe
"Description" AT24C32D-SSHM-B, EEPROM Memory 32kbit,, 4096 x, 8bit, Serial-2 Wire, 550ns 1.7  5.5 V, 8-Pin SOIC
"Datasheet Link" http://www.atmel.com/images/atmel-8866-seeprom-at24c32d-datasheet.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
AT24C32D-SSHM-B
1 0 U A0
2 0 U A1
3 0 U A2
4 0 U GND
8 0 U VCC
7 0 U WP
6 0 U SCL
5 0 U SDA

*END*
*REMARK* SamacSys ECAD Model
166196/1906581/2.50/8/3/Integrated Circuit
