*PADS-LIBRARY-PART-TYPES-V9*

TCAN3413DR SOIC127P600X175-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.02.25.14.37.17
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TCAN3413DR
"Mouser Part Number" 595-TCAN3413DR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TCAN3413DR?qs=mELouGlnn3eIMT2B6sccyw%3D%3D
"Arrow Part Number" TCAN3413DR
"Arrow Price/Stock" https://www.arrow.com/en/products/tcan3413dr/texas-instruments?utm_currency=USD&region=nac
"Description" 1/1 Transceiver Half CANbus 8-SOIC
"Datasheet Link" https://www.ti.com/lit/ds/symlink/tcan3413.pdf?ts=1704463166829&ref_url=https%253A%252F%252Fwww.ti.com%252Fproduct%252Fde-de%252FTCAN3413
"Geometry.Height" 1.75mm
GATE 1 8 0
TCAN3413DR
1 0 U TXD
2 0 U GND
3 0 U VCC
4 0 U RXD
8 0 U STB
7 0 U CANH
6 0 U CANL
5 0 U SHDNV_IO

*END*
*REMARK* SamacSys ECAD Model
19298845/1906581/2.50/8/3/Integrated Circuit
